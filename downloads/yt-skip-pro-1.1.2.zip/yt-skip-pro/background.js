chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "wall") {
    chrome.storage.local.set({ wallAt: Date.now() });
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#d93025" });
  }
});

chrome.runtime.onInstalled.addListener(() => chrome.action.setBadgeText({ text: "" }));
