const DEFAULTS = {
  enabled: true,
  autoSkip: true,
  hideFeedAds: true,
  hideBanners: true,
};

const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(DEFAULTS, (cfg) => {
  for (const key of Object.keys(DEFAULTS)) {
    const el = $(key);
    el.checked = !!cfg[key];
    el.addEventListener("change", () =>
      chrome.storage.sync.set({ [key]: el.checked })
    );
  }
});

function renderWarning() {
  chrome.storage.local.get({ wallAt: 0 }, (s) => {
    // Show the warning if YouTube's ad blocker notice was seen in the last 10 minutes
    $("wall").hidden = !(s.wallAt && Date.now() - s.wallAt < 10 * 60 * 1000);
  });
}
renderWarning();
chrome.storage.onChanged.addListener(renderWarning);
