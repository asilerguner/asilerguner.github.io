(() => {
  "use strict";

  const DEFAULTS = {
    enabled: true,
    autoSkip: true,
    hideFeedAds: true,
    hideBanners: true,
  };

  // YouTube renames these now and then, so look for several variants.
  const SKIP_SELECTORS = [
    ".ytp-skip-ad-button",
    ".ytp-ad-skip-button",
    ".ytp-ad-skip-button-modern",
    ".ytp-ad-skip-button-container button",
    ".ytp-ad-skip-button-slot button",
    ".ytp-skip-ad button",
    "button[class*='skip-button']",
    "button[id^='skip-button']",
  ];

  let cfg = { ...DEFAULTS };
  let wallSeen = false;

  // ---------- Settings ----------
  function applyClasses() {
    const r = document.documentElement;
    if (!r) return;
    r.classList.toggle("ytsp-feed", cfg.enabled && cfg.hideFeedAds);
    r.classList.toggle("ytsp-banner", cfg.enabled && cfg.hideBanners);
  }

  function loadSettings() {
    chrome.storage.sync.get(DEFAULTS, (res) => {
      cfg = { ...DEFAULTS, ...res };
      applyClasses();
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    for (const k in changes) cfg[k] = changes[k].newValue;
    applyClasses();
  });

  function report(type) {
    try {
      chrome.runtime.sendMessage({ type });
    } catch (_) {
      /* extension was reloaded; page still has the old context */
    }
  }

  // ---------- Helpers ----------
  const getPlayer = () => document.querySelector("#movie_player");

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const s = getComputedStyle(el);
    return s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
  }

  // The skip button only exists while an ad is playing, so there is no need to
  // check for the ad first. Looking inside the player keeps it from clicking
  // unrelated buttons elsewhere on the page.
  function findSkipButton() {
    const root = getPlayer() || document;
    for (const sel of SKIP_SELECTORS) {
      for (const el of root.querySelectorAll(sel)) {
        if (!el.disabled && isVisible(el)) return el;
      }
    }
    return null;
  }

  // Send the same events a real click does, in the same order.
  function press(el) {
    const r = el.getBoundingClientRect();
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: r.left + r.width / 2,
      clientY: r.top + r.height / 2,
      button: 0,
    };
    el.dispatchEvent(new PointerEvent("pointerdown", init));
    el.dispatchEvent(new MouseEvent("mousedown", init));
    el.dispatchEvent(new PointerEvent("pointerup", init));
    el.dispatchEvent(new MouseEvent("mouseup", init));
    el.dispatchEvent(new MouseEvent("click", init));
  }

  // ---------- Detect YouTube's ad blocker warning, so the popup can tell you ----------
  function checkWall() {
    if (wallSeen) return;
    if (document.querySelector("ytd-enforcement-message-view-model")) {
      wallSeen = true;
      report("wall");
    }
  }

  // ---------- Ad handling ----------
  let lastPress = 0;

  function skipAd() {
    if (!cfg.autoSkip) return;
    if (Date.now() - lastPress < 400) return;
    const btn = findSkipButton();
    if (!btn) return;
    lastPress = Date.now();
    press(btn);
  }

  function tick() {
    checkWall();
    if (!cfg.enabled) return;
    skipAd();

    if (cfg.hideBanners) {
      document
        .querySelectorAll(".ytp-ad-overlay-close-button")
        .forEach((b) => b.click());
    }
  }

  // ---------- Start ----------
  loadSettings();
  let scheduled = false;
  const schedule = () => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      tick();
    });
  };

  function start() {
    new MutationObserver(schedule).observe(document.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["class"],
    });
    setInterval(tick, 300);
  }

  if (document.documentElement) start();
  else document.addEventListener("DOMContentLoaded", start);
})();
