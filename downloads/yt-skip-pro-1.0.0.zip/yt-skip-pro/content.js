(() => {
  "use strict";

  const DEFAULTS = {
    enabled: true,
    autoSkip: true,
    hideFeedAds: true,
    hideBanners: true,
    aggressive: false, // mute + speed up + seek to end (high detection risk)
  };

  const SKIP_SELECTORS = [
    ".ytp-skip-ad-button",
    ".ytp-ad-skip-button",
    ".ytp-ad-skip-button-modern",
    ".ytp-ad-skip-button-container button",
  ];

  let cfg = { ...DEFAULTS };
  let wallSeen = false;
  let skipCounted = false;
  let aggressiveState = null; // { muted, rate }

  // ---------- Settings ----------
  function applyClasses() {
    const r = document.documentElement;
    if (!r) return;
    r.classList.toggle("ytsp-feed", cfg.enabled && cfg.hideFeedAds);
    r.classList.toggle("ytsp-banner", cfg.enabled && cfg.hideBanners);
  }

  function loadSettings() {
    chrome.storage.sync.get(DEFAULTS, (res) => {
      cfg = { ...DEFAULTS, ...res };
      applyClasses();
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    for (const k in changes) cfg[k] = changes[k].newValue;
    applyClasses();
  });

  function report(type) {
    try {
      chrome.runtime.sendMessage({ type });
    } catch (_) {
      /* extension was reloaded; page still has the old context */
    }
  }

  // ---------- Helpers ----------
  const getPlayer = () => document.querySelector("#movie_player");

  function isAdShowing(player) {
    if (!player || !player.classList.contains("ad-showing")) return false;
    return !!player.querySelector(
      ".ytp-ad-player-overlay-layout, .ytp-ad-player-overlay, .ytp-ad-preview-container, .ytp-ad-skip-button-container, .ytp-ad-text"
    );
  }

  function findSkipButton() {
    for (const sel of SKIP_SELECTORS) {
      const el = document.querySelector(sel);
      if (el && el.offsetParent !== null) return el;
    }
    return null;
  }

  // ---------- Enforcement wall detection: safe mode ----------
  function checkWall() {
    if (wallSeen) return;
    if (document.querySelector("ytd-enforcement-message-view-model")) {
      wallSeen = true;
      report("wall");
    }
  }

  // ---------- Ad handling ----------
  function handleAd(player) {
    const video = player.querySelector("video.html5-main-video");

    // 1) Skippable ad: click the button once it appears
    const btn = cfg.autoSkip ? findSkipButton() : null;
    if (btn) {
      btn.click();
      if (!skipCounted) {
        skipCounted = true;
        report("skipped");
      }
      return;
    }

    // 2) Aggressive mode (off by default, disabled once the wall is seen)
    if (cfg.aggressive && !wallSeen && video) {
      if (!aggressiveState) {
        const rate = video.playbackRate || 1;
        aggressiveState = { muted: video.muted, rate: rate > 4 ? 1 : rate };
      }
      video.muted = true;
      video.playbackRate = 16;
      if (
        video.readyState >= 1 &&
        isFinite(video.duration) &&
        video.duration > 0 &&
        video.duration <= 180
      ) {
        video.currentTime = Math.max(0, video.duration - 0.1);
        if (!skipCounted) {
          skipCounted = true;
          report("skipped");
        }
      }
      if (video.paused) video.play().catch(() => {});
    }
  }

  function restore(player) {
    skipCounted = false;
    if (!aggressiveState) return;
    const video = player && player.querySelector("video.html5-main-video");
    if (video) {
      video.muted = aggressiveState.muted;
      video.playbackRate = aggressiveState.rate;
      if (video.paused) video.play().catch(() => {});
    }
    aggressiveState = null;
  }

  function tick() {
    checkWall();
    if (!cfg.enabled) {
      restore(getPlayer());
      return;
    }
    const player = getPlayer();
    if (isAdShowing(player)) handleAd(player);
    else restore(player);

    if (cfg.hideBanners) {
      document
        .querySelectorAll(".ytp-ad-overlay-close-button")
        .forEach((b) => b.click());
    }
  }

  // ---------- Start ----------
  loadSettings();
  let scheduled = false;
  const schedule = () => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      tick();
    });
  };

  function start() {
    new MutationObserver(schedule).observe(document.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["class"],
    });
    setInterval(tick, 500);
  }

  if (document.documentElement) start();
  else document.addEventListener("DOMContentLoaded", start);
})();
