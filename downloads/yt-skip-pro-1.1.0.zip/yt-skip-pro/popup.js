const DEFAULTS = {
  enabled: true,
  autoSkip: true,
  hideFeedAds: true,
  hideBanners: true,
};

const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(DEFAULTS, (cfg) => {
  for (const key of Object.keys(DEFAULTS)) {
    const el = $(key);
    el.checked = !!cfg[key];
    el.addEventListener("change", () =>
      chrome.storage.sync.set({ [key]: el.checked })
    );
  }
});

function renderStats() {
  chrome.storage.local.get({ total: 0, today: 0, day: "", wallAt: 0 }, (s) => {
    const sameDay = s.day === new Date().toDateString();
    $("today").textContent = sameDay ? s.today : 0;
    $("total").textContent = s.total;
    // Show the warning if the wall was seen in the last 10 minutes
    $("wall").hidden = !(s.wallAt && Date.now() - s.wallAt < 10 * 60 * 1000);
  });
}
renderStats();
chrome.storage.onChanged.addListener(renderStats);

$("reset").addEventListener("click", () => {
  chrome.storage.local.set({ total: 0, today: 0, day: "", wallAt: 0 });
  chrome.action.setBadgeText({ text: "" });
});
