function setBadge(text, color) {
  chrome.action.setBadgeText({ text });
  if (color) chrome.action.setBadgeBackgroundColor({ color });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "skipped") {
    chrome.storage.local.get({ total: 0, today: 0, day: "" }, (s) => {
      const day = new Date().toDateString();
      const today = s.day === day ? s.today + 1 : 1;
      const total = s.total + 1;
      chrome.storage.local.set({ total, today, day });
      setBadge(String(today), "#2f6fed");
    });
  } else if (msg.type === "wall") {
    chrome.storage.local.set({ wallAt: Date.now() });
    setBadge("!", "#d93025");
  }
});

chrome.runtime.onInstalled.addListener(() => setBadge(""));
