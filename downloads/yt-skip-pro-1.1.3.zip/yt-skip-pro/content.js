(() => {
  "use strict";

  const DEFAULTS = {
    enabled: true,
    autoSkip: true,
    hideFeedAds: true,
    hideBanners: true,
  };

  // YouTube renames these now and then, so look for several variants.
  const SKIP_SELECTORS = [
    ".ytp-skip-ad-button",
    ".ytp-ad-skip-button",
    ".ytp-ad-skip-button-modern",
    ".ytp-ad-skip-button-container button",
    ".ytp-ad-skip-button-slot button",
    ".ytp-skip-ad button",
    "button[class*='skip-button']",
    "button[id^='skip-button']",
  ];

  let cfg = { ...DEFAULTS };
  let wallSeen = false;

  // ---------- Settings ----------
  function applyClasses() {
    const r = document.documentElement;
    if (!r) return;
    r.classList.toggle("ytsp-feed", cfg.enabled && cfg.hideFeedAds);
    r.classList.toggle("ytsp-banner", cfg.enabled && cfg.hideBanners);
  }

  function loadSettings() {
    chrome.storage.sync.get(DEFAULTS, (res) => {
      cfg = { ...DEFAULTS, ...res };
      applyClasses();
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    for (const k in changes) cfg[k] = changes[k].newValue;
    applyClasses();
  });

  function report(type) {
    try {
      chrome.runtime.sendMessage({ type });
    } catch (_) {
      /* extension was reloaded; page still has the old context */
    }
  }

  // ---------- Helpers ----------
  const getPlayer = () => document.querySelector("#movie_player");

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const s = getComputedStyle(el);
    return s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
  }

  const SKIP_TEXT =
    /^(skip( ad| ads)?|hoppa över|atla|reklamı atla|überspringen|passer|saltar|pular|salta|overslaan)\b/i;

  // Last resort: YouTube sometimes renames its classes, so find the button by
  // what it says. Only used while an ad is playing.
  function findSkipByText(root) {
    if (!root || !root.querySelectorAll) return null;
    for (const el of root.querySelectorAll("button, [role='button']")) {
      const t = (el.getAttribute("aria-label") || el.textContent || "").trim();
      if (t.length > 0 && t.length < 30 && SKIP_TEXT.test(t) && !el.disabled && isVisible(el)) {
        return el;
      }
    }
    return null;
  }

  function findSkipButton() {
    const player = getPlayer();
    const roots = [player, document].filter(Boolean);
    for (const root of roots) {
      for (const sel of SKIP_SELECTORS) {
        for (const el of root.querySelectorAll(sel)) {
          if (!el.disabled && isVisible(el)) return el;
        }
      }
    }
    const adPlaying =
      player &&
      (player.classList.contains("ad-showing") ||
        player.classList.contains("ad-interrupting"));
    return adPlaying ? findSkipByText(player) : null;
  }

  // Send the same events a real click does, in the same order.
  function press(el) {
    const r = el.getBoundingClientRect();
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: r.left + r.width / 2,
      clientY: r.top + r.height / 2,
      button: 0,
    };
    el.dispatchEvent(new PointerEvent("pointerdown", init));
    el.dispatchEvent(new MouseEvent("mousedown", init));
    el.dispatchEvent(new PointerEvent("pointerup", init));
    el.dispatchEvent(new MouseEvent("mouseup", init));
    el.dispatchEvent(new MouseEvent("click", init));
  }

  // If one way of clicking does not work, try the next one on the next pass.
  const attempts = new WeakMap();
  function activate(el) {
    const n = attempts.get(el) || 0;
    attempts.set(el, n + 1);
    if (n === 0) press(el);
    else if (n === 1) el.click();
    else if (n === 2) {
      el.focus();
      for (const type of ["keydown", "keyup"]) {
        el.dispatchEvent(
          new KeyboardEvent(type, { key: "Enter", code: "Enter", keyCode: 13, bubbles: true })
        );
      }
    }
  }

  // ---------- Detect YouTube's ad blocker warning, so the popup can tell you ----------
  function checkWall() {
    if (wallSeen) return;
    if (document.querySelector("ytd-enforcement-message-view-model")) {
      wallSeen = true;
      report("wall");
    }
  }

  // ---------- Ad handling ----------
  let lastPress = 0;

  function skipAd() {
    if (!cfg.autoSkip) return;
    if (Date.now() - lastPress < 400) return;
    const btn = findSkipButton();
    if (!btn) return;
    lastPress = Date.now();
    activate(btn);
  }

  function tick() {
    checkWall();
    if (!cfg.enabled) return;
    skipAd();

    if (cfg.hideBanners) {
      document
        .querySelectorAll(".ytp-ad-overlay-close-button")
        .forEach((b) => b.click());
    }
  }

  // ---------- Start ----------
  loadSettings();
  let scheduled = false;
  const schedule = () => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      tick();
    });
  };

  function start() {
    new MutationObserver(schedule).observe(document.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["class"],
    });
    setInterval(tick, 300);
  }

  if (document.documentElement) start();
  else document.addEventListener("DOMContentLoaded", start);
})();
